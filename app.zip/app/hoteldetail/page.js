import React, { Suspense } from 'react'
import Header from '@/component/Header'
import SearchHotelDetail from '@/Components/SearchResultPage/HotelDetail/SearchHotelDetail'

export default function page() {
    return (
        <>
            <Header />
            <Suspense fallback={<div>Loading...</div>}>
                <SearchHotelDetail />
            </Suspense>
        </>
    )
}

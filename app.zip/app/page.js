
"use client"
import Footer from "@/component/Footer";
import Header from "@/component/Header";
import Blogs from "@/Components/HomePage/Blog/Blogs";
import DestinationSection from "@/Components/HomePage/DestinationSection/DestinationSection";
import ExperienceExploreSection from "@/Components/HomePage/ExpereinceExploreSection/ExperienceExploreSection";
import GetOfferSection from "@/Components/HomePage/GetOfferSection/GetOfferSection";
import HomeBannerSection from "@/Components/HomePage/HomeBannerSection";
import RecomendSection from "@/Components/HomePage/RecommendedSection/RecomendSection";
// import SearchSection from "@/Components/HomePage/SearchSectionhhh";
import "../style/responsive.css"

export default function Home() {
  return (
    <>
      <Header />
      {/* <SearchSection /> */}
      <HomeBannerSection />
      <div className="container">
        <DestinationSection />
        <RecomendSection />
        <GetOfferSection />
        <ExperienceExploreSection />
        <Blogs />
      </div>
      <Footer />
    </>
  )
}

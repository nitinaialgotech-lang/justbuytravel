import Header from '@/component/Header'
import React from 'react'

export default function page() {
    return (
        <>
            <Header />
            <section>
                <div className='container'>
                    <div className='row'>




                    </div>

                </div>


            </section>

        </>
    )
}
